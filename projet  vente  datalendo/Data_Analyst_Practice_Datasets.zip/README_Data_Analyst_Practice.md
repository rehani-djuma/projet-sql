
# FINANCE

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine finance.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# BANKING

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine banking.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# ECOMMERCE

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine ecommerce.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# RETAIL

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine retail.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# HEALTHCARE

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine healthcare.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# NGO

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine ngo.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# HR

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine hr.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# TELECOM

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine telecom.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# EDUCATION

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine education.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# MARKETING

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine marketing.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# LOGISTICS

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine logistics.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count


# REAL_ESTATE

## Business Context
Dataset réaliste utilisé pour pratiquer la Data Analysis dans le domaine real_estate.

## KPI à analyser
- Revenue / Budget
- Performance
- Growth
- Cost Analysis
- Conversion / Churn
- Customer Insights

## Business Questions
- Quels sont les produits/services les plus performants ?
- Quelles régions performent mieux ?
- Où trouve-t-on les anomalies ?
- Quels segments génèrent plus de revenus ?

## Data Cleaning Challenges
- Valeurs manquantes
- Doublons
- Incohérences
- Formats à standardiser

## Dashboards recommandés
- KPI Dashboard
- Trend Analysis
- Geographic Dashboard
- Customer Analytics

## SQL Practice Ideas
- GROUP BY
- JOIN
- Window Functions
- Aggregations
- Ranking

## DAX Measures
- Total Revenue
- Profit Margin
- Growth Rate
- Average Transaction
- Customer Count
